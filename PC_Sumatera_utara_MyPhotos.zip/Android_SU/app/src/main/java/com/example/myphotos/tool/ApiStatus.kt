package com.example.myphotos.tool

enum class ApiStatus {
    SUCCESS, FAILED
}