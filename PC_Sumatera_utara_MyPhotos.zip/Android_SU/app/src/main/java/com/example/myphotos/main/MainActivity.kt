package com.example.myphotos.main

import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Toast
import com.example.myphotos.R
import com.example.myphotos.databinding.ActivityMainBinding
import com.example.myphotos.tool.*
import org.json.JSONObject

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var preferences: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(this.layoutInflater)
        preferences = getSharedPreferences(Const.PREF_NAME, MODE_PRIVATE)

        setContentView(binding.root)

        setFolderList()
    }

    private fun setFolderList() {
        with(binding) {
            if (preferences.getString("id", null) == null) {
                getId()
            }

            val id = preferences.getString(Const.ID, null)

            if (id == null) {
                Toast.makeText(this@MainActivity, "Failed to get id", Toast.LENGTH_SHORT)
            }

            val listener = object : SimpleListener {
                override fun onFinished(wrapper: ApiWrapper) {
                    if (wrapper.status == ApiStatus.SUCCESS && wrapper.body != null) {
                        val folderIds = arrayListOf<String>()
                        val folderNames = arrayListOf<String>()
                        val folders = wrapper.body.getJSONArray("data")

                        for (i in 0 until folders.length()) {
                            folderIds.add(folders.getJSONObject(i).getString("id"))
                            folderNames.add(folders.getJSONObject(i).getString("name"))
                        }

                        runOnUiThread {
                            folderList.adapter = ArrayAdapter(this@MainActivity, R.layout.folder_item, folderNames.toTypedArray())
                        }
                    }
                }
            }

            val url = Const.BASE_URL + "/users/$id/albums"
            val folderHelper = ApiHelper(url, "GET", null, listener)
        }
    }

    private fun getId() {
        val listener = object : SimpleListener {
            override fun onFinished(wrapper: ApiWrapper) {
                if (wrapper.status == ApiStatus.SUCCESS && wrapper.body != null) {
                    preferences.edit().putString(Const.ID, wrapper.body.getJSONObject("data").getString("id")).apply()
                }
            }
        }

        val token = preferences.getString(Const.TOKEN, "-")
        val helper = ApiHelper(Const.BASE_URL + "/users/me", "GET", null, listener)
        if (token != null) {
            helper.setHeader("Authorization", token)
        }

        helper.execute()
    }

}