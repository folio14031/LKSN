package com.example.myphotos.register

import android.content.Intent
import android.content.SharedPreferences
import android.os.AsyncTask
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.JsonReader
import android.widget.Toast
import com.example.myphotos.R
import com.example.myphotos.databinding.ActivityLoginBinding
import com.example.myphotos.databinding.ActivityRegisterBinding
import com.example.myphotos.tool.*
import org.json.JSONObject
import java.lang.Exception
import java.util.concurrent.Executors

class RegisterActivity : AppCompatActivity() {

    private lateinit var binding: ActivityRegisterBinding
    private lateinit var preferences: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        preferences = getSharedPreferences(Const.PREF_NAME, MODE_PRIVATE)
        binding = ActivityRegisterBinding.inflate(this.layoutInflater)

        setContentView(binding.root)

        setButton()
    }

    private fun setButton() {
        with(binding) {
            regLoginBtn.setOnClickListener {
                finish()
            }

            regBackBtn.setOnClickListener {
                finish()
            }

            regBtn.setOnClickListener {
                val email = regEmailEt.text.toString()
                val username = regNameEt.text.toString()
                val password = regPasswordEt.text.toString()
                val confirm = regConfirmEt.text.toString()

                val emailVer = Verifier.vEmail(email)
                val passwordVer = Verifier.vPassword(password)
                val usernameVer = Verifier.vUsername(username)

                regEmailEt.error = emailVer
                regPasswordEt.error = passwordVer
                regNameEt.error = usernameVer

                if (password != confirm) {
                    regConfirmEt.error = "Password not match!"
                    return@setOnClickListener
                } else {
                    regConfirmEt.error = null
                }

                if (emailVer == null && passwordVer == null && usernameVer == null)
                    register(email, username, password, confirm)
            }
        }
    }

    private fun register(email: String, name: String, password: String, confirmPassword: String) {
        val params = JSONObject()
        params.put("name", name)
        params.put("email", email)

        params.put("password", password)
        params.put("password_confirmation", confirmPassword)

        val helper = ApiHelper("${Const.BASE_URL}/users", "POST", params,
                object : SimpleListener {
                    override fun onFinished(wrapper: ApiWrapper) {
                        try {
                            val json = wrapper.body

                            if (wrapper.status == ApiStatus.SUCCESS && json != null) {
                                val userId = json.getJSONObject("data").getString("id")

                                preferences.edit().apply {
                                    putString(Const.ID, userId)
                                    putString(Const.EMAIL, email)
                                    putString(Const.NAME, name)
                                    commit()
                                }

                                runOnUiThread {
                                    Toast.makeText(this@RegisterActivity, "Register Success!", Toast.LENGTH_LONG).show()
                                    finish()
                                }
                            } else {
                                var message = "";

                                try {
                                    message = json?.getString("message").toString()
                                } catch (e: Exception) {
                                    e.printStackTrace()
                                }

                                runOnUiThread {
                                    Toast.makeText(
                                        this@RegisterActivity,
                                        "Register failed\n\n" + message,
                                        Toast.LENGTH_LONG
                                    ).show()
                                }

                            }
                        } catch (e: Exception) {
                            e.printStackTrace()
                            runOnUiThread {
                                Toast.makeText(
                                    this@RegisterActivity,
                                    "Internal error happened : \n\n" + e.message,
                                    Toast.LENGTH_LONG
                                ).show()
                            }
                        }
                    }

                }
            )
        helper.execute()
    }
}