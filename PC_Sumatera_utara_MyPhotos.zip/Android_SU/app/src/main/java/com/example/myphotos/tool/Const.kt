package com.example.myphotos.tool

object Const {
    val BASE_URL = "http://54.151.137.160/api/v1"
    val PREF_NAME = "Myphotospref"

    val ID = "id"
    val NAME = "name"
    val EMAIL = "email"
    val TOKEN = "token"
    val EXPIRE = "expire"
}