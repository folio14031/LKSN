package com.example.myphotos.tool

import android.provider.ContactsContract

object Verifier {

    fun vUsername(username: String): String? {
        if (username.contains("\\W".toRegex())) {
            return "Username must not contains symbols"
        }

        return null
    }

    fun vEmail(email: String): String? {
        if (!email.contains("@") || !email.contains(".")) {
            return "Wrong email fomat!"
        }

        return null
    }


    fun vPassword(password: String): String? {
        if (password.length <= 8) {
            return "Password must be more than 8 Characters"
        } else if (!password.contains("[0-9]".toRegex())) {
            return "Password must contains number"
        }else if (!password.contains("[a-z]".toRegex())) {
            return "Password must contains lowercase"
        }else if (!password.contains("[A-Z]".toRegex())) {
            return "Password must contains uppercase"
        }else if (!password.contains("^[a-zA-Z0-9]".toRegex())) {
            return "Password must contains symbols"
        }

        return null
    }
}