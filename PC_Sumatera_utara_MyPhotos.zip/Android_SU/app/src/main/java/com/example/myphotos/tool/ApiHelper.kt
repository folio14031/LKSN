package com.example.myphotos.tool

import android.os.AsyncTask
import android.util.JsonReader
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.lang.Exception
import java.net.HttpURLConnection
import java.net.URL

class ApiHelper(private val urlStr: String, private val method: String, private val postBody: JSONObject?, private val listener: SimpleListener): AsyncTask<Unit, Unit, Unit>() {

    private val url: URL
    private val con: HttpURLConnection

    init {
        url = URL(urlStr)
        con = url.openConnection() as HttpURLConnection

        if (method == "POST" || method == "PUT") {
            con.doOutput = true

        }

        con.doInput = true

        con.addRequestProperty("Accept", "application/json")
        con.addRequestProperty("Content-Type", "application/json")

        con.requestMethod = method
    }

    public fun setHeader(k: String, v: String) {
        con.addRequestProperty(k, v)
    }

    override fun doInBackground(vararg params: Unit?): Unit {
        var status = ApiStatus.FAILED

        try {
            val writer = con.outputStream.bufferedWriter()
            writer.write(postBody.toString())
            writer.flush()
            writer.close()

            con.connect()

            status = if (con.responseCode in 200..299) {
                ApiStatus.SUCCESS
            } else {
                ApiStatus.FAILED
            }

            val reader =
                if (con.responseCode in 400..499) con.errorStream.bufferedReader()
                else con.inputStream.bufferedReader()

            val json = JSONObject(reader.readText())

            println("Message : " + con.responseCode + "\n " + json.toString())

            listener.onFinished(ApiWrapper(status, json))
            reader.close()
            con.disconnect()
        } catch (e: Exception) {
            e.printStackTrace()
            listener.onFinished(ApiWrapper(status, null))
        }
    }

}