package com.example.myphotos.tool

import org.json.JSONObject

data class ApiWrapper(
    val status: ApiStatus,
    val body: JSONObject?
)
