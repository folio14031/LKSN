package com.example.myphotos.login

import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.core.app.ActivityCompat
import com.example.myphotos.R
import com.example.myphotos.databinding.ActivityLoginBinding
import com.example.myphotos.main.MainActivity
import com.example.myphotos.register.RegisterActivity
import com.example.myphotos.tool.*
import org.json.JSONObject

class LoginActivity : AppCompatActivity() {

    companion object {
        val REQ_CODE = 309
    }

    lateinit var binding: ActivityLoginBinding
    private lateinit var preferences: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        preferences = getSharedPreferences(Const.PREF_NAME, MODE_PRIVATE)
        binding = ActivityLoginBinding.inflate(this.layoutInflater)

        setContentView(binding.root)

        if (preferences.getLong(Const.EXPIRE, 0) > System.currentTimeMillis()) {
            goMain()
        }

        checkPerm()
        setButton()
    }

    private fun setButton() {
        with(binding) {
            registerBtn.setOnClickListener {
                val register = Intent(this@LoginActivity, RegisterActivity::class.java)
                startActivity(register)
            }

            loginBtn.setOnClickListener {
                val email = emailEt.text.toString()
                val password = passwordEt.text.toString()

                val emailVer = Verifier.vEmail(email)
                val passwordVer = Verifier.vPassword(password)

                emailEt.error = emailVer
                passwordEt.error = passwordVer

                if (emailVer == null && passwordVer == null)
                    login(email, password)
            }
        }
    }

    private fun login(email: String, password: String) {
        val params = JSONObject()
        params.put("email", email)
        params.put("password", password)

        val listener = object : SimpleListener {
            override fun onFinished(wrapper: ApiWrapper) {
                val json = wrapper.body

                if (wrapper.status == ApiStatus.SUCCESS&& json != null) {
                    val token = "Bearer " + json.getJSONObject("data").getString("signature")
                    val expireSec = json.getJSONObject("data").getInt("expires_in")
                    val expireLong = expireSec*1000 + System.currentTimeMillis()

                    preferences.edit().apply {
                        putString(Const.TOKEN, token)
                        putLong(Const.EXPIRE, expireLong)
                    }

                    runOnUiThread {
                        Toast.makeText(this@LoginActivity, "Login Success!", Toast.LENGTH_LONG).show()
                        goMain()
                    }
                } else {
                    runOnUiThread {
                        Toast.makeText(this@LoginActivity, "Login failed\n\n" + json?.getString("message"), Toast.LENGTH_LONG).show()
                    }
                }
            }

        }

        val helper = ApiHelper("${Const.BASE_URL}/auth", "POST", params, listener)
        helper.execute()

    }

    private fun goMain() {
        val main = Intent(this, MainActivity::class.java)
        startActivity(main)
    }

    private fun checkPerm() {
        if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                arrayOf(android.Manifest.permission.READ_EXTERNAL_STORAGE),
                REQ_CODE
            )
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        if (requestCode == REQ_CODE) {
            if (grantResults[0] != PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Please grant access for photos", Toast.LENGTH_SHORT).show()
                finish()
            }
        }

        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
    }
}