package com.example.myphotos.tool

interface SimpleListener {
    fun onFinished(wrapper: ApiWrapper)
}