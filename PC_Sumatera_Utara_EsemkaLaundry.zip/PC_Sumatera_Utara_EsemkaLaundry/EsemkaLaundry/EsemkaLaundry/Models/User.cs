﻿using System;
using System.Collections.Generic;

#nullable disable

namespace EsemkaLaundry.Models {
    public partial class User {
        public User(BaseUser user) {
            this.Email = user.Email;
            this.Name = user.Name;
            this.Password = user.Password;
            this.Gender = user.Gender;
            this.DateOfBirth = user.DateOfBirth;
            this.PhoneNumber = user.PhoneNumber;
            this.Address = user.Address;
            this.Role = user.Role;
            this.PhotoPath = user.PhotoPath;
        }

        public string Email { get; set; }
        public string Name { get; set; }
        public string Password { get; set; }
        private int Gender { get; set; }
       
        public DateTime DateOfBirth { get; set; }
        public string PhoneNumber { get; set; }
        public string Address { get; set; }
        public int Role { get; set; }
        public string PhotoPath { get; set; }
    }
}
