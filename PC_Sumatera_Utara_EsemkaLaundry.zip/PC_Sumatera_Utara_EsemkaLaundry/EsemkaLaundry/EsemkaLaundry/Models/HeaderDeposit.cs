﻿using System;
using System.Collections.Generic;

#nullable disable

namespace EsemkaLaundry.Models
{
    public partial class HeaderDeposit
    {
        public HeaderDeposit()
        {
            DetailDeposits = new HashSet<DetailDeposit>();
        }

        public Guid Id { get; set; }
        public string CustomerEmail { get; set; }
        public string EmployeeEmail { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime EstimationAt { get; set; }
        public DateTime? CompletedAt { get; set; }

        public virtual BaseUser CustomerEmailNavigation { get; set; }
        public virtual BaseUser EmployeeEmailNavigation { get; set; }
        public virtual ICollection<DetailDeposit> DetailDeposits { get; set; }
    }
}
