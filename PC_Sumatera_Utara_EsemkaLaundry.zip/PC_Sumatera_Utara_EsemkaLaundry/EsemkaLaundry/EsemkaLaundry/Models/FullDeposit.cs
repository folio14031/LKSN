﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EsemkaLaundry.Models {
    public class FullDeposit {
        public Guid Id { get; set; }
        public string CustomerEmail { get; set; }
        public User Customer { get; set; }

        public string EmployeeEmail { get; set; }
        public User Employee { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime EstimationAt { get; set; }
        public DateTime? CompletedAt { get; set; }
    }
}
