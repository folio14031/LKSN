﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EsemkaLaundry.Models {
    public enum UserGender {
        Female = 0,
        Male = 1
    }
}
