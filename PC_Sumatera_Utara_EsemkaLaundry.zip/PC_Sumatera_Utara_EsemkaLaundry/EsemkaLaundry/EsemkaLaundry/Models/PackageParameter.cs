﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EsemkaLaundry.Models {
    public class PackageParameter {
        public Guid Id { get; set; }
        public Guid ServiceId { get; set; }
        public double Total { get; set; }
        public double Price { get; set; }
    }
}
