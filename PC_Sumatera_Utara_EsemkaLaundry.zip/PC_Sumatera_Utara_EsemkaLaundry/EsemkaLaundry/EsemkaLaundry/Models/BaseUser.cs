﻿using System;
using System.Collections.Generic;

#nullable disable

namespace EsemkaLaundry.Models
{
    public partial class BaseUser
    {
        public BaseUser()
        {
            HeaderDepositCustomerEmailNavigations = new HashSet<HeaderDeposit>();
            HeaderDepositEmployeeEmailNavigations = new HashSet<HeaderDeposit>();
            PackageTransactions = new HashSet<FullPackageTransaction>();
        }

        public string Email { get; set; }
        public string Name { get; set; }
        public string Password { get; set; }
        public int Gender { get; set; }
        public DateTime DateOfBirth { get; set; }
        public string PhoneNumber { get; set; }
        public string Address { get; set; }
        public int Role { get; set; }
        public string PhotoPath { get; set; }

        public virtual ICollection<HeaderDeposit> HeaderDepositCustomerEmailNavigations { get; set; }
        public virtual ICollection<HeaderDeposit> HeaderDepositEmployeeEmailNavigations { get; set; }
        public virtual ICollection<FullPackageTransaction> PackageTransactions { get; set; }
    }
}
