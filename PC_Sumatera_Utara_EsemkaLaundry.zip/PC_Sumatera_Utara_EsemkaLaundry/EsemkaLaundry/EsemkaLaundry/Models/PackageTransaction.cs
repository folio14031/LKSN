﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EsemkaLaundry.Models {
    public class PackageTransaction {
        public PackageTransaction(FullPackageTransaction package) {
            this.Id = package.Id;
            this.UserEmail = package.UserEmail;
            this.PackageId = package.PackageId;
            this.Price = package.Price;
            this.AvailableUnit = package.AvailableUnit;
            this.CreatedAt = package.CreatedAt;
            this.CompletedAt = package.CompletedAt;
            this.Package = new Package(package.Package);
            this.User = new User(package.UserEmailNavigation);
        }

        public Guid Id { get; set; }
        public string UserEmail { get; set; }
        public virtual User User { get; set; }
        public Guid PackageId { get; set; }
        public virtual Package Package { get; set; }
        public double Price { get; set; }
        public double AvailableUnit { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime? CompletedAt { get; set; }
        
        
    }
}
