﻿using System;
using System.Collections.Generic;

#nullable disable

namespace EsemkaLaundry.Models
{
    public partial class FullPackageTransaction
    {
        public FullPackageTransaction()
        {
            DetailDeposits = new HashSet<DetailDeposit>();
        }

        public Guid Id { get; set; }
        public string UserEmail { get; set; }
        public Guid PackageId { get; set; }
        public double Price { get; set; }
        public double AvailableUnit { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime? CompletedAt { get; set; }

        public virtual FullPackage Package { get; set; }
        public virtual BaseUser UserEmailNavigation { get; set; }
        public virtual ICollection<DetailDeposit> DetailDeposits { get; set; }
    }
}
