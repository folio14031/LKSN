﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EsemkaLaundry.Models {
    public class Service {
        public Service (FullService full) {
            this.Id = full.Id;
            this.Name = full.Name;
            this.Category = full.Category;
            this.Unit = full.Unit;
            this.Price = full.Price;
            this.EstimationDuration = full.EstimationDuration;
        }

        public Guid Id { get; set; }
        public string Name { get; set; }
        public int Category { get; set; }
        public int Unit { get; set; }
        public double Price { get; set; }
        public int EstimationDuration { get; set; }
    }
}
