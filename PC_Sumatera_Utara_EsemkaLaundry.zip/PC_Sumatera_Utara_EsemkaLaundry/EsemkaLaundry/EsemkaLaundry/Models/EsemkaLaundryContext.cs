﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

#nullable disable

namespace EsemkaLaundry.Models
{
    public partial class EsemkaLaundryContext : DbContext
    {
        public EsemkaLaundryContext()
        {
        }

        public EsemkaLaundryContext(DbContextOptions<EsemkaLaundryContext> options)
            : base(options)
        {
        }

        public virtual DbSet<DetailDeposit> DetailDeposits { get; set; }
        public virtual DbSet<HeaderDeposit> HeaderDeposits { get; set; }
        public virtual DbSet<FullPackage> Packages { get; set; }
        public virtual DbSet<FullPackageTransaction> PackageTransactions { get; set; }
        public virtual DbSet<FullService> Services { get; set; }
        public virtual DbSet<BaseUser> Users { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
               optionsBuilder.UseSqlServer("Data Source=.\\SQLEXPRESS;Initial Catalog=EsemkaLaundry;Integrated Security=True");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("Relational:Collation", "Latin1_General_CI_AS");

            modelBuilder.Entity<DetailDeposit>(entity =>
            {
                entity.HasIndex(e => e.HeaderDepositId, "IX_DetailDeposits_HeaderDepositId");

                entity.HasIndex(e => e.PackageTransactionId, "IX_DetailDeposits_PackageTransactionId");

                entity.HasIndex(e => e.ServiceId, "IX_DetailDeposits_ServiceId");

                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.HasOne(d => d.HeaderDeposit)
                    .WithMany(p => p.DetailDeposits)
                    .HasForeignKey(d => d.HeaderDepositId);

                entity.HasOne(d => d.PackageTransaction)
                    .WithMany(p => p.DetailDeposits)
                    .HasForeignKey(d => d.PackageTransactionId);

                entity.HasOne(d => d.Service)
                    .WithMany(p => p.DetailDeposits)
                    .HasForeignKey(d => d.ServiceId);
            });

            modelBuilder.Entity<HeaderDeposit>(entity =>
            {
                entity.HasIndex(e => e.CustomerEmail, "IX_HeaderDeposits_CustomerEmail");

                entity.HasIndex(e => e.EmployeeEmail, "IX_HeaderDeposits_EmployeeEmail");

                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.CustomerEmail)
                    .IsRequired()
                    .HasMaxLength(100);

                entity.Property(e => e.EmployeeEmail)
                    .IsRequired()
                    .HasMaxLength(100);

                entity.HasOne(d => d.CustomerEmailNavigation)
                    .WithMany(p => p.HeaderDepositCustomerEmailNavigations)
                    .HasForeignKey(d => d.CustomerEmail)
                    .OnDelete(DeleteBehavior.ClientSetNull);

                entity.HasOne(d => d.EmployeeEmailNavigation)
                    .WithMany(p => p.HeaderDepositEmployeeEmailNavigations)
                    .HasForeignKey(d => d.EmployeeEmail)
                    .OnDelete(DeleteBehavior.ClientSetNull);
            });

            modelBuilder.Entity<FullPackage>(entity =>
            {
                entity.HasIndex(e => e.ServiceId, "IX_Packages_ServiceId");

                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.HasOne(d => d.Service)
                    .WithMany(p => p.Packages)
                    .HasForeignKey(d => d.ServiceId);
            });

            modelBuilder.Entity<FullPackageTransaction>(entity =>
            {
                entity.HasIndex(e => e.PackageId, "IX_PackageTransactions_PackageId");

                entity.HasIndex(e => e.UserEmail, "IX_PackageTransactions_UserEmail");

                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.UserEmail).HasMaxLength(100);

                entity.HasOne(d => d.Package)
                    .WithMany(p => p.PackageTransactions)
                    .HasForeignKey(d => d.PackageId);

                entity.HasOne(d => d.UserEmailNavigation)
                    .WithMany(p => p.PackageTransactions)
                    .HasForeignKey(d => d.UserEmail);
            });

            modelBuilder.Entity<FullService>(entity =>
            {
                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(100);
            });

            modelBuilder.Entity<BaseUser>(entity =>
            {
                entity.HasKey(e => e.Email);

                entity.Property(e => e.Email).HasMaxLength(100);

                entity.Property(e => e.Address)
                    .IsRequired()
                    .HasMaxLength(300);

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(100);

                entity.Property(e => e.Password)
                    .IsRequired()
                    .HasMaxLength(200);

                entity.Property(e => e.PhoneNumber)
                    .IsRequired()
                    .HasMaxLength(20);

                entity.Property(e => e.PhotoPath).HasMaxLength(200);
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
