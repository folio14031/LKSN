﻿using System;
using System.Collections.Generic;

#nullable disable

namespace EsemkaLaundry.Models
{
    public partial class DetailDeposit
    {
        public Guid Id { get; set; }
        public Guid HeaderDepositId { get; set; }
        public Guid ServiceId { get; set; }
        public Guid? PackageTransactionId { get; set; }
        public double Price { get; set; }
        public double Total { get; set; }
        public DateTime? CompletedAt { get; set; }

        public virtual HeaderDeposit HeaderDeposit { get; set; }
        public virtual FullPackageTransaction PackageTransaction { get; set; }
        public virtual FullService Service { get; set; }
    }
}
