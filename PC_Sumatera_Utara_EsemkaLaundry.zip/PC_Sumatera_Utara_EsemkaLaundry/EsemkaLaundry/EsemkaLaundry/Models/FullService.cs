﻿using System;
using System.Collections.Generic;

#nullable disable

namespace EsemkaLaundry.Models
{
    public partial class FullService
    {
        public FullService()
        {
            DetailDeposits = new HashSet<DetailDeposit>();
            Packages = new HashSet<FullPackage>();
        }

        public Guid Id { get; set; }
        public string Name { get; set; }
        public int Category { get; set; }
        public int Unit { get; set; }
        public double Price { get; set; }
        public int EstimationDuration { get; set; }

        public virtual ICollection<DetailDeposit> DetailDeposits { get; set; }
        public virtual ICollection<FullPackage> Packages { get; set; }
    }
}
