﻿using System;
using System.Collections.Generic;

#nullable disable

namespace EsemkaLaundry.Models
{
    public partial class FullPackage
    {
        public FullPackage()
        {
            PackageTransactions = new HashSet<FullPackageTransaction>();
        }

        public Guid Id { get; set; }
        public Guid ServiceId { get; set; }
        public double Total { get; set; }
        public double Price { get; set; }

        public virtual FullService Service { get; set; }
        public virtual ICollection<FullPackageTransaction> PackageTransactions { get; set; }
    }
}
