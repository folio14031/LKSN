﻿using System;
using System.Collections.Generic;

#nullable disable

namespace EsemkaLaundry.Models
{
    public partial class Package
    {
        public Package(FullPackage fp)
        {
            this.Id = fp.Id;
            this.ServiceId = fp.ServiceId;
            this.Total = fp.Total;
            this.Price = fp.Price;
            this.Service = new Service(fp.Service);
        }

        public Guid Id { get; set; }
        public Guid ServiceId { get; set; }
        

        public virtual Service Service { get; set; }

        public double Total { get; set; }
        public double Price { get; set; }
    }
}
