﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EsemkaLaundry.Models {
    public class DepositParameter {
        public string CustomerEmail { get; set; }
        public DetailDepositParameter[] services { get; set; }
    }
}
