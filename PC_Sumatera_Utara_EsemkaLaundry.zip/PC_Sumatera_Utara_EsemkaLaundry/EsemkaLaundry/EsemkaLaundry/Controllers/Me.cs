﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EsemkaLaundry.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace EsemkaLaundry.Controllers {
    [Route("api/Me")]
    [ApiController]
    public class Me : Controller {
        private readonly EsemkaLaundryContext _context;

        public Me(EsemkaLaundryContext context) {
            _context = context;
        }

        // GET: api/Me
        [HttpGet]
        public async Task<ActionResult<User>> GetMe() {
            var fullUser =  await _context.Users.FindAsync("bamys2@baidu.com");
            return new User(fullUser);
        }

        // PUT: api/Me
        [HttpPut]
        public async Task<IActionResult> PutMe(User param) {
            if (!UserExists(param.Email)) return NotFound();

            _context.Entry(param).State = EntityState.Modified;

            try {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException) {
                if (!UserExists(param.Email)) 
                    return NotFound();
                else
                    throw;
            }

            return NoContent();
        }

        private bool UserExists(string id) {
            return _context.Users.Any(e => e.Email == id);
        }
    }
}
