﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using EsemkaLaundry.Models;

namespace EsemkaLaundry.Controllers
{
    [Route("api/Packages/Transactions")]
    [ApiController]
    public class PackageTransactionsController : ControllerBase
    {
        private readonly EsemkaLaundryContext _context;

        public PackageTransactionsController(EsemkaLaundryContext context)
        {
            _context = context;
        }

        // GET: api/PackageTransactions
        [HttpGet]
        public async Task<ActionResult<IEnumerable<PackageTransaction>>> GetPackageTransactions()
        {
            var fullPackagesTr = await _context.PackageTransactions.ToListAsync();
            var packagesTr = new List<PackageTransaction>();

            foreach (var fp in fullPackagesTr) {
                packagesTr.Add(new PackageTransaction(fp));
            }

            return packagesTr;
        }

        // GET: api/PackageTransactions/5
        [HttpGet("{id}")]
        public async Task<ActionResult<PackageTransaction>> GetPackageTransaction(Guid id)
        {
            var packageTransaction = await _context.PackageTransactions.FindAsync(id);

            if (packageTransaction == null)
            {
                return NotFound();
            }

            return new PackageTransaction(packageTransaction);
        }

        // POST: api/PackageTransactions
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<FullPackageTransaction>> PostPackageTransaction(FullPackageTransaction packageTransaction)
        {
            _context.PackageTransactions.Add(packageTransaction);
            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException)
            {
                if (PackageTransactionExists(packageTransaction.Id))
                {
                    return Conflict();
                }
                else
                {
                    throw;
                }
            }

            return CreatedAtAction("GetPackageTransaction", new { id = packageTransaction.Id }, packageTransaction);
        }

        private bool PackageTransactionExists(Guid id)
        {
            return _context.PackageTransactions.Any(e => e.Id == id);
        }
    }
}
