﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EsemkaLaundry.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace EsemkaLaundry.Controllers {
    [Route("api/Deposits")]
    [ApiController]
    public class Deposits : Controller {
        private readonly EsemkaLaundryContext _context;

        public Deposits(EsemkaLaundryContext context) {
            _context = context;
        }

        // GET: Deposits
        [HttpGet]
        public async Task<ActionResult<IEnumerable<FullDeposit>>> GetDeposits() {
            IEnumerable<HeaderDeposit> depositHeaders = await _context.HeaderDeposits.ToListAsync();
            List<FullDeposit> fullDeposits = new List<FullDeposit>();

            foreach (var header in depositHeaders) {
                BaseUser customer = _context.Users.Find(header.CustomerEmail);
                BaseUser employee = _context.Users.Find(header.EmployeeEmail);

                User simpleCustomer = new User(customer);
                User simpleEmployee = new User(employee);

                FullDeposit deposit = new FullDeposit();

                deposit.Id = header.Id;
                deposit.CustomerEmail = header.CustomerEmail;
                deposit.Customer = simpleCustomer;
                deposit.EmployeeEmail = header.EmployeeEmail;
                deposit.Employee = simpleEmployee;
                deposit.CreatedAt = header.CreatedAt;
                deposit.EstimationAt = header.EstimationAt;
                deposit.CompletedAt = header.CompletedAt;

                fullDeposits.Add(deposit);
            }

            return fullDeposits;
        }

        // GET: Deposits/guid
        [HttpGet("{id}")]
        public async Task<ActionResult<FullDeposit>> GetDepositsById(Guid id) {
            HeaderDeposit header = await _context.HeaderDeposits.FindAsync(id);

            if (header == null) {
                return NotFound();
            }

            BaseUser customer = _context.Users.Find(header.CustomerEmail);
            BaseUser employee = _context.Users.Find(header.EmployeeEmail);

            User simpleCustomer = new User(customer);
            User simpleEmployee = new User(employee);

            FullDeposit deposit = new FullDeposit();

            deposit.Id = header.Id;
            deposit.CustomerEmail = header.CustomerEmail;
            deposit.Customer = simpleCustomer;
            deposit.EmployeeEmail = header.EmployeeEmail;
            deposit.Employee = simpleEmployee;
            deposit.CreatedAt = header.CreatedAt;
            deposit.EstimationAt = header.EstimationAt;
            deposit.CompletedAt = header.CompletedAt;

            return deposit;
        }


        private bool HeaderDepositExists(Guid id) {
            return _context.HeaderDeposits.Any(e => e.Id == id);
        }
    }
}
