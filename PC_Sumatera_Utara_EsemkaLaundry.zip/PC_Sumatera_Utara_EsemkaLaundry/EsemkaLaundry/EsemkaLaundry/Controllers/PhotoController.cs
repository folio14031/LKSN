﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EsemkaLaundry.Controllers {
    [Route("api/Me/Photo")]
    [ApiController]
    public class PhotoController : Controller {

    }
}
