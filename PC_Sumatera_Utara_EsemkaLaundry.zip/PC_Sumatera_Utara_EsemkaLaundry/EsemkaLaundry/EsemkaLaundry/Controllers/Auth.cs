﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using EsemkaLaundry.Models;

namespace EsemkaLaundry.Controllers {
    [Route("api/Auth")]
    [ApiController]
    public class Auth : Controller {

        private readonly EsemkaLaundryContext _context;
        public Auth(EsemkaLaundryContext context) {
            _context = context;
        }

        // POST: api/Auth
        [HttpPost]
        public async Task<ActionResult<string>> PostAuth(Models.LoginParameter auth) {
            bool isExists = await UserExists(auth.Email, auth.Password);

            try {
                if (isExists) {
                    return "token";
                } else {
                    return NotFound();
                }
            }
            catch (Exception) {
                if (isExists) {
                    return NotFound();
                }
                else {
                    return NotFound();
                    throw;
                }
            }
        }

        private async Task<bool> UserExists(string email, string password) {
            return await _context.Users.AnyAsync(e => e.Email == email && e.Password == password);
        }
    }
}
