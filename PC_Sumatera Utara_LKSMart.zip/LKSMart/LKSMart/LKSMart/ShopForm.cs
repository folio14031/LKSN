﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace LKSMart {
    public partial class ShopForm : Form {

        private static int? price1 = null;
        private static int? price2 = null;
        private static string currentKey = "";

        public ShopForm() {
            InitializeComponent();
        }

        private void ShopForm_Load(object sender, EventArgs e) {
            fetchAll("", price1, price2);
        }


        private void fetchAll(string keyword, int? p1, int? p2) {
            currentKey = keyword;
            string priceQuery = "";

            if (p1 != null) {
                priceQuery += " AND price > " + p1;
            }

            if (p2 != null) {
                priceQuery += " AND price < " + p2;
            }

            using (var dt = Db.queryDt($"SELECT id, name, price, stock FROM [dbo].[product] WHERE name like '%{keyword}%'" + priceQuery)) {
                ProductDgv.DataSource = dt;
            }
        }

        private void BackBtn_Click(object sender, EventArgs e) {
            Close();
        }

        private void price1Tb_TextChanged(object sender, EventArgs e) {

        }

        private void button2_Click(object sender, EventArgs e) {
            var p1 = price1Tb.Text;
            var p2 = price2Tb.Text;

            int pp1, pp2;

            if (Int32.TryParse(p1, out pp1) && Int32.TryParse(p2, out pp2)) {
                price1 = pp1;
                price2 = pp2;

                fetchAll(currentKey, price1, price2);
            } else {
                MessageBox.Show("Invalid price!");
            }
            
        }

        private void KeywordTb_TextChanged_1(object sender, EventArgs e) {
            fetchAll(KeywordTb.Text, price1, price2);
        }

        private void ProductDgv_CellContentClick(object sender, DataGridViewCellEventArgs e) {

        }

        private void ProductDgv_CellClick(object sender, DataGridViewCellEventArgs e) {
            var id = Int32.Parse(ProductDgv.SelectedRows[0].Cells[0].Value.ToString());

            using (var dt = Db.queryDt($"SELECT * FROM [dbo].[product] WHERE id = {id}")) {
                var item = dt.Rows[0];

                NameLabel.Text = "Name : " + item.ItemArray[2] as string;
                PriceLabel.Text = "Price : Rp. " + Int32.Parse(item.ItemArray[3].ToString());
                StockLabel.Text = "Stock : " + Int32.Parse(item.ItemArray[4].ToString());

                var filename = item.ItemArray[5].ToString() + ".png";

                prodPb.Image = Image.FromFile(Base.defaultProdPath + filename);
            }
        }
    }
}
