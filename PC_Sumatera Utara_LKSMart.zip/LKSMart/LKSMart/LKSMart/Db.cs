﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Windows.Forms;

namespace LKSMart {
    class Db {
        static String conStr = "Data Source=.\\SQLEXPRESS;Initial Catalog=LKSMart;Integrated Security=True";
        static SqlConnection con = null;

        public static void connect() {
            if (con == null) {
                con = new SqlConnection(conStr);
            }

            if (con.State == ConnectionState.Closed) con.Open();
        }

        public static DataTable queryDt(String query) {
            connect();
            
            try {
                var dt = new DataTable();
                var cmd = new SqlCommand(query, con);
                var reader = cmd.ExecuteReader();

                dt.Load(reader);

                return dt;
            }
            catch (Exception e) {
                Console.WriteLine("Error querying data : " + e.Message);
                MessageBox.Show("Failed to fetch data. try again or send this error message to admin :\n\n" + e.Message);
                return null;
            }
        }

        public static void queryNonDt(String query) {
            connect();

            try {
                var dt = new DataTable();
                var cmd = new SqlCommand(query, con);
                cmd.ExecuteNonQuery();
            }
            catch (Exception e) {
                Console.WriteLine("Error querying data : " + e.Message);
                MessageBox.Show("Failed to fetch data. try again or send this error message to admin :\n\n" + e.Message);
            }
        }
    }
}
