﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Text.RegularExpressions;

namespace LKSMart {
    class Base {
        public static int? id = null;
        public static string defaultProfilePath = Directory.GetCurrentDirectory() + "\\images\\profile_pictures\\";
        public static string defaultProdPath = Directory.GetCurrentDirectory() + "\\images\\products\\";
        public static string defaultProfileName = "default_profile_picture.png";

        private bool checkNumExists(string str) {
            return Regex.IsMatch(str, "\\D");
        }
    }
}
