﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using System.IO;

namespace LKSMart {
    public partial class LoginForm : Form {
        public LoginForm() {
            InitializeComponent();
        }

        private void LoginBtn_Click(object sender, EventArgs e) {
            if (verify()) {
                Login();
            }
        }

        private bool verify() {
            var id = EmailTb.Text;
            var pin = PinTb.Text;

            if (String.IsNullOrWhiteSpace(id)) {
                MessageBox.Show("Phone number or Email is empty!");
                return false;
            }

            if (String.IsNullOrWhiteSpace(pin)) {
                MessageBox.Show("PIN is empty!");
                return false;
            }

            if (!id.Contains('@')) {
                if (Regex.IsMatch(id, "[^0-9-]")) {
                    MessageBox.Show("Phone number invalid!");
                    return false;
                }
            }

            return true;
        }

        private void Login() {
            var id = EmailTb.Text;
            var pin = PinTb.Text;

            using (var dt = Db.queryDt($"SELECT * FROM [dbo].[Customer] WHERE phone_number LIKE '{id}' OR email LIKE '{id}' AND pin_number like '{pin}'")) {
                if (dt != null) {
                    if (dt.Rows.Count == 0) {
                        MessageBox.Show("No User Found!");
                    } else {
                        if (!String.IsNullOrEmpty(dt.Rows[0].ItemArray[12].ToString())) {
                            MessageBox.Show("No User Found!");
                            return;
                        }

                        Base.id = (int) dt.Rows[0].ItemArray[0];

                        Hide();
                        (new MainForm()).Show();
                    }
                }
            }
        }

        private void label1_Click(object sender, EventArgs e) {

        }

        private void LoginForm_Load(object sender, EventArgs e) {
        }

        private void LoginForm_FormClosed(object sender, FormClosedEventArgs e) {
           
        }
    }
}
