﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using System.IO;

namespace LKSMart {
    public partial class ProfileForm : Form {

        private static int id = 0;

        public ProfileForm() {
            InitializeComponent();
        }

        private void Profile_Load(object sender, EventArgs e) {
            if (Base.id != null) {
                id = (int)Base.id;
            }

            load();
        }

        private void load() {
            using (var dt = Db.queryDt($"SELECT * FROM [dbo].[customer] WHERE id = {id}")) {
                var row = dt.Rows[0];
                var dateStr = row.ItemArray[5] as string;
                var gender = row.ItemArray[7] as string;
                var profileImageName = row.ItemArray[9] as string;

                NameTb.Text = row.ItemArray[1] as string;
                PhoneTb.Text = row.ItemArray[2] as string;
                EmailTb.Text = row.ItemArray[3] as string;
                PinTb.Text = row.ItemArray[4] as string;
                
                if (dateStr == null) {
                    BirthDtp.Text = null;
                } else {
                    BirthDtp.Value = DateTime.Parse(dateStr);
                }

                AddressTb.Text = row.ItemArray[6] as string;

                if (!String.IsNullOrEmpty(profileImageName))
                    profilePb.BackgroundImage = Image.FromFile(Base.defaultProfilePath + profileImageName + ".png");
                else
                    profilePb.BackgroundImage = Image.FromFile(Base.defaultProfilePath + Base.defaultProfileName);

                if (gender == null) {
                    genderCb.SelectedIndex = 0;
                } else {
                    genderCb.SelectedItem = gender;
                }

            }
        }

        private void NameEditBtn_Click(object sender, EventArgs e) {
            var name = NameTb.Text;

            if (String.IsNullOrWhiteSpace(name)) {
                NameErrLabel.Text = "Name is empty";
                return;
            } else if (Regex.IsMatch(name, "\\W")) {
                NameErrLabel.Text = "Name is invalid";
                return;
            }

            Db.queryNonDt($"UPDATE [dbo].[Customer] SET name = '{name}', last_updated_at = '{getLastUpdate()}' WHERE id = {id}");
            load();
        }

        private void PinEditBtn_Click(object sender, EventArgs e) {
            var pin = PinTb.Text;

            if (String.IsNullOrWhiteSpace(pin)) {
                PinErrLabel.Text = "Pin is empty";
            }
            else if (Regex.IsMatch(pin, "\\D")) {
                PinErrLabel.Text = "Pin must be only digits";
                return;
            } else if (pin.Length != 6) {
                PinErrLabel.Text = "Pin must be 6 digits";
                return;
            }

            Db.queryNonDt($"UPDATE [dbo].[Customer] SET pin_number = '{pin}', last_updated_at = '{getLastUpdate()}' WHERE id = {id}");
            load();
        }

        private void DateEditBtn_Click(object sender, EventArgs e) {
            var dateStr = BirthDtp.Text;

            if (String.IsNullOrWhiteSpace(dateStr)) {
                Db.queryNonDt($"UPDATE [dbo].[Customer] SET date_of_birth = NULL, last_updated_at = '{getLastUpdate()}' WHERE id = {id}");
                load();
            } else if (DateTime.TryParse(dateStr, out _)) {
                Db.queryNonDt($"UPDATE [dbo].[Customer] SET date_of_birth = '{dateStr}', last_updated_at = '{getLastUpdate()}' WHERE id = {id}");
                load();
            } else {
                DateErrLabel.Text = "Date format invalid";
                return;
            }
        }

        private void GenderEditTb_Click(object sender, EventArgs e) {
            string gender = null;

            if (genderCb.Text != "Not Set" && genderCb.Text != "Male" && genderCb.Text != "Female") {
                MessageBox.Show("Gender invalid! please select from options");
                return;
            } else if (genderCb.Text != "Not Set") {
                gender = genderCb.Text;
            }

            Db.queryNonDt($"UPDATE [dbo].[Customer] SET gender = '{gender}', last_updated_at = '{getLastUpdate()}' WHERE id = {id}");
            load();
        }

        private void AddressEditTb_Click(object sender, EventArgs e) {
            var address = AddressTb.Text;

            if (String.IsNullOrWhiteSpace(address)) {
                MessageBox.Show("Address is empty");
                return;
            }

            Db.queryNonDt($"UPDATE [dbo].[Customer] SET address = '{address}', last_updated_at = '{getLastUpdate()}' WHERE id = {id}");
            load();
        }

        private void profileUpdateBtn_Click(object sender, EventArgs e) {
            if (openFileDialog1.ShowDialog() == DialogResult.OK) {
                try {
                    var filename = openFileDialog1.FileName;

                    if (!filename.Contains(".png")) {
                        MessageBox.Show("Please use png image!");
                        return;
                    }

                    var newName = DateTime.Now.ToString("yyyyMMddHHmmss");
                    File.Copy(openFileDialog1.FileName, Base.defaultProfilePath + newName + ".png");
                    profilePb.BackgroundImage = Image.FromFile(Base.defaultProfilePath + newName + ".png");

                    Db.queryNonDt($"UPDATE [dbo].[Customer] SET profile_image_name = '{newName}', last_updated_at = '{getLastUpdate()}' WHERE id = {id}");
                    load();
                }
                catch (Exception ex) {
                    MessageBox.Show("Failed to updating profile picture!\n\nError : " + ex.Message);
                }
            }
        }

        private string getLastUpdate() {
            return DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff");
        }

        private void BackBtn_Click(object sender, EventArgs e) {
            Close();
        }
    }
}
