﻿
namespace LKSMart {
    partial class ProfileForm {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.label1 = new System.Windows.Forms.Label();
            this.BackBtn = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.NameTb = new System.Windows.Forms.TextBox();
            this.PhoneTb = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.EmailTb = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.PinTb = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.AddressTb = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.genderCb = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.profileUpdateBtn = new System.Windows.Forms.Button();
            this.profilePb = new System.Windows.Forms.PictureBox();
            this.NameEditBtn = new System.Windows.Forms.Button();
            this.PinEditBtn = new System.Windows.Forms.Button();
            this.AddressEditTb = new System.Windows.Forms.Button();
            this.DateEditBtn = new System.Windows.Forms.Button();
            this.GenderEditTb = new System.Windows.Forms.Button();
            this.BirthDtp = new System.Windows.Forms.DateTimePicker();
            this.NameErrLabel = new System.Windows.Forms.Label();
            this.PinErrLabel = new System.Windows.Forms.Label();
            this.DateErrLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.profilePb)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(13, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(103, 37);
            this.label1.TabIndex = 0;
            this.label1.Text = "Profile";
            // 
            // BackBtn
            // 
            this.BackBtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.BackBtn.Location = new System.Drawing.Point(689, 13);
            this.BackBtn.Name = "BackBtn";
            this.BackBtn.Size = new System.Drawing.Size(115, 37);
            this.BackBtn.TabIndex = 1;
            this.BackBtn.Text = "Back";
            this.BackBtn.UseVisualStyleBackColor = true;
            this.BackBtn.Click += new System.EventHandler(this.BackBtn_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(52, 124);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(41, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Name :";
            // 
            // NameTb
            // 
            this.NameTb.Location = new System.Drawing.Point(102, 124);
            this.NameTb.Name = "NameTb";
            this.NameTb.Size = new System.Drawing.Size(307, 20);
            this.NameTb.TabIndex = 3;
            // 
            // PhoneTb
            // 
            this.PhoneTb.Location = new System.Drawing.Point(102, 159);
            this.PhoneTb.Name = "PhoneTb";
            this.PhoneTb.Size = new System.Drawing.Size(307, 20);
            this.PhoneTb.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 162);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(84, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Phone Number :";
            // 
            // EmailTb
            // 
            this.EmailTb.Location = new System.Drawing.Point(102, 200);
            this.EmailTb.Name = "EmailTb";
            this.EmailTb.Size = new System.Drawing.Size(307, 20);
            this.EmailTb.TabIndex = 7;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(51, 200);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(38, 13);
            this.label4.TabIndex = 6;
            this.label4.Text = "Email :";
            // 
            // PinTb
            // 
            this.PinTb.Location = new System.Drawing.Point(102, 240);
            this.PinTb.Name = "PinTb";
            this.PinTb.Size = new System.Drawing.Size(307, 20);
            this.PinTb.TabIndex = 9;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(55, 243);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(34, 13);
            this.label5.TabIndex = 8;
            this.label5.Text = "PIN : ";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(12, 283);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(77, 13);
            this.label6.TabIndex = 10;
            this.label6.Text = "Date Of Birth : ";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(31, 327);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(54, 13);
            this.label7.TabIndex = 12;
            this.label7.Text = "Address : ";
            // 
            // AddressTb
            // 
            this.AddressTb.Location = new System.Drawing.Point(102, 327);
            this.AddressTb.Multiline = true;
            this.AddressTb.Name = "AddressTb";
            this.AddressTb.Size = new System.Drawing.Size(307, 127);
            this.AddressTb.TabIndex = 13;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(41, 473);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(48, 13);
            this.label8.TabIndex = 14;
            this.label8.Text = "Gender :";
            // 
            // genderCb
            // 
            this.genderCb.FormattingEnabled = true;
            this.genderCb.Items.AddRange(new object[] {
            "Not Set",
            "Male",
            "Female"});
            this.genderCb.Location = new System.Drawing.Point(103, 473);
            this.genderCb.Name = "genderCb";
            this.genderCb.Size = new System.Drawing.Size(306, 21);
            this.genderCb.TabIndex = 15;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(12, 516);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(81, 13);
            this.label9.TabIndex = 17;
            this.label9.Text = "Profile Picture : ";
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // profileUpdateBtn
            // 
            this.profileUpdateBtn.Location = new System.Drawing.Point(263, 561);
            this.profileUpdateBtn.Name = "profileUpdateBtn";
            this.profileUpdateBtn.Size = new System.Drawing.Size(80, 38);
            this.profileUpdateBtn.TabIndex = 18;
            this.profileUpdateBtn.Text = "Upload";
            this.profileUpdateBtn.UseVisualStyleBackColor = true;
            this.profileUpdateBtn.Click += new System.EventHandler(this.profileUpdateBtn_Click);
            // 
            // profilePb
            // 
            this.profilePb.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.profilePb.Location = new System.Drawing.Point(102, 515);
            this.profilePb.Name = "profilePb";
            this.profilePb.Size = new System.Drawing.Size(146, 125);
            this.profilePb.TabIndex = 16;
            this.profilePb.TabStop = false;
            // 
            // NameEditBtn
            // 
            this.NameEditBtn.Location = new System.Drawing.Point(424, 122);
            this.NameEditBtn.Name = "NameEditBtn";
            this.NameEditBtn.Size = new System.Drawing.Size(75, 23);
            this.NameEditBtn.TabIndex = 19;
            this.NameEditBtn.Text = "Edit";
            this.NameEditBtn.UseVisualStyleBackColor = true;
            this.NameEditBtn.Click += new System.EventHandler(this.NameEditBtn_Click);
            // 
            // PinEditBtn
            // 
            this.PinEditBtn.Location = new System.Drawing.Point(424, 238);
            this.PinEditBtn.Name = "PinEditBtn";
            this.PinEditBtn.Size = new System.Drawing.Size(75, 23);
            this.PinEditBtn.TabIndex = 22;
            this.PinEditBtn.Text = "Edit";
            this.PinEditBtn.UseVisualStyleBackColor = true;
            this.PinEditBtn.Click += new System.EventHandler(this.PinEditBtn_Click);
            // 
            // AddressEditTb
            // 
            this.AddressEditTb.Location = new System.Drawing.Point(424, 325);
            this.AddressEditTb.Name = "AddressEditTb";
            this.AddressEditTb.Size = new System.Drawing.Size(75, 23);
            this.AddressEditTb.TabIndex = 24;
            this.AddressEditTb.Text = "Edit";
            this.AddressEditTb.UseVisualStyleBackColor = true;
            this.AddressEditTb.Click += new System.EventHandler(this.AddressEditTb_Click);
            // 
            // DateEditBtn
            // 
            this.DateEditBtn.Location = new System.Drawing.Point(424, 278);
            this.DateEditBtn.Name = "DateEditBtn";
            this.DateEditBtn.Size = new System.Drawing.Size(75, 23);
            this.DateEditBtn.TabIndex = 23;
            this.DateEditBtn.Text = "Edit";
            this.DateEditBtn.UseVisualStyleBackColor = true;
            this.DateEditBtn.Click += new System.EventHandler(this.DateEditBtn_Click);
            // 
            // GenderEditTb
            // 
            this.GenderEditTb.Location = new System.Drawing.Point(424, 471);
            this.GenderEditTb.Name = "GenderEditTb";
            this.GenderEditTb.Size = new System.Drawing.Size(75, 23);
            this.GenderEditTb.TabIndex = 25;
            this.GenderEditTb.Text = "Edit";
            this.GenderEditTb.UseVisualStyleBackColor = true;
            this.GenderEditTb.Click += new System.EventHandler(this.GenderEditTb_Click);
            // 
            // BirthDtp
            // 
            this.BirthDtp.Location = new System.Drawing.Point(102, 280);
            this.BirthDtp.Name = "BirthDtp";
            this.BirthDtp.Size = new System.Drawing.Size(307, 20);
            this.BirthDtp.TabIndex = 26;
            // 
            // NameErrLabel
            // 
            this.NameErrLabel.AutoSize = true;
            this.NameErrLabel.ForeColor = System.Drawing.Color.Red;
            this.NameErrLabel.Location = new System.Drawing.Point(534, 127);
            this.NameErrLabel.Name = "NameErrLabel";
            this.NameErrLabel.Size = new System.Drawing.Size(0, 13);
            this.NameErrLabel.TabIndex = 27;
            // 
            // PinErrLabel
            // 
            this.PinErrLabel.AutoSize = true;
            this.PinErrLabel.ForeColor = System.Drawing.Color.Red;
            this.PinErrLabel.Location = new System.Drawing.Point(534, 243);
            this.PinErrLabel.Name = "PinErrLabel";
            this.PinErrLabel.Size = new System.Drawing.Size(0, 13);
            this.PinErrLabel.TabIndex = 28;
            // 
            // DateErrLabel
            // 
            this.DateErrLabel.AutoSize = true;
            this.DateErrLabel.ForeColor = System.Drawing.Color.Red;
            this.DateErrLabel.Location = new System.Drawing.Point(534, 283);
            this.DateErrLabel.Name = "DateErrLabel";
            this.DateErrLabel.Size = new System.Drawing.Size(0, 13);
            this.DateErrLabel.TabIndex = 29;
            // 
            // ProfileForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(816, 670);
            this.Controls.Add(this.DateErrLabel);
            this.Controls.Add(this.PinErrLabel);
            this.Controls.Add(this.NameErrLabel);
            this.Controls.Add(this.BirthDtp);
            this.Controls.Add(this.GenderEditTb);
            this.Controls.Add(this.AddressEditTb);
            this.Controls.Add(this.DateEditBtn);
            this.Controls.Add(this.PinEditBtn);
            this.Controls.Add(this.NameEditBtn);
            this.Controls.Add(this.profileUpdateBtn);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.profilePb);
            this.Controls.Add(this.genderCb);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.AddressTb);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.PinTb);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.EmailTb);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.PhoneTb);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.NameTb);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.BackBtn);
            this.Controls.Add(this.label1);
            this.Name = "ProfileForm";
            this.Text = "Profile";
            this.Load += new System.EventHandler(this.Profile_Load);
            ((System.ComponentModel.ISupportInitialize)(this.profilePb)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button BackBtn;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox NameTb;
        private System.Windows.Forms.TextBox PhoneTb;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox EmailTb;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox PinTb;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox genderCb;
        private System.Windows.Forms.PictureBox profilePb;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Button profileUpdateBtn;
        private System.Windows.Forms.Button NameEditBtn;
        private System.Windows.Forms.Button PinEditBtn;
        private System.Windows.Forms.Button AddressEditTb;
        private System.Windows.Forms.Button DateEditBtn;
        private System.Windows.Forms.Button GenderEditTb;
        private System.Windows.Forms.DateTimePicker BirthDtp;
        private System.Windows.Forms.Label NameErrLabel;
        private System.Windows.Forms.Label PinErrLabel;
        private System.Windows.Forms.Label DateErrLabel;
        private System.Windows.Forms.TextBox AddressTb;
    }
}