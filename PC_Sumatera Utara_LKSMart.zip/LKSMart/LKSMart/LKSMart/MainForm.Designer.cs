﻿
namespace LKSMart {
    partial class MainForm {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.ProfilePb = new System.Windows.Forms.PictureBox();
            this.WelcomeLabel = new System.Windows.Forms.Label();
            this.TimeLabel = new System.Windows.Forms.Label();
            this.LogoutBtn = new System.Windows.Forms.Button();
            this.CartBtn = new System.Windows.Forms.Button();
            this.ProfileBtn = new System.Windows.Forms.Button();
            this.ShopBtn = new System.Windows.Forms.Button();
            this.TransactionBtn = new System.Windows.Forms.Button();
            this.PointBtn = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.ProfilePb)).BeginInit();
            this.SuspendLayout();
            // 
            // ProfilePb
            // 
            this.ProfilePb.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.ProfilePb.Location = new System.Drawing.Point(13, 13);
            this.ProfilePb.Name = "ProfilePb";
            this.ProfilePb.Size = new System.Drawing.Size(107, 93);
            this.ProfilePb.TabIndex = 0;
            this.ProfilePb.TabStop = false;
            // 
            // WelcomeLabel
            // 
            this.WelcomeLabel.AutoSize = true;
            this.WelcomeLabel.Location = new System.Drawing.Point(127, 13);
            this.WelcomeLabel.Name = "WelcomeLabel";
            this.WelcomeLabel.Size = new System.Drawing.Size(61, 13);
            this.WelcomeLabel.TabIndex = 1;
            this.WelcomeLabel.Text = "Welcome, !";
            // 
            // TimeLabel
            // 
            this.TimeLabel.AutoSize = true;
            this.TimeLabel.Location = new System.Drawing.Point(130, 30);
            this.TimeLabel.Name = "TimeLabel";
            this.TimeLabel.Size = new System.Drawing.Size(30, 13);
            this.TimeLabel.TabIndex = 2;
            this.TimeLabel.Text = "Time";
            // 
            // LogoutBtn
            // 
            this.LogoutBtn.Location = new System.Drawing.Point(864, 13);
            this.LogoutBtn.Name = "LogoutBtn";
            this.LogoutBtn.Size = new System.Drawing.Size(135, 58);
            this.LogoutBtn.TabIndex = 3;
            this.LogoutBtn.Text = "Logout";
            this.LogoutBtn.UseVisualStyleBackColor = true;
            this.LogoutBtn.Click += new System.EventHandler(this.LogoutBtn_Click);
            // 
            // CartBtn
            // 
            this.CartBtn.Image = global::LKSMart.Properties.Resources.cart;
            this.CartBtn.Location = new System.Drawing.Point(734, 13);
            this.CartBtn.Name = "CartBtn";
            this.CartBtn.Size = new System.Drawing.Size(124, 58);
            this.CartBtn.TabIndex = 4;
            this.CartBtn.UseVisualStyleBackColor = true;
            // 
            // ProfileBtn
            // 
            this.ProfileBtn.BackgroundImage = global::LKSMart.Properties.Resources.profile;
            this.ProfileBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.ProfileBtn.Location = new System.Drawing.Point(50, 198);
            this.ProfileBtn.Name = "ProfileBtn";
            this.ProfileBtn.Size = new System.Drawing.Size(147, 114);
            this.ProfileBtn.TabIndex = 5;
            this.ProfileBtn.UseVisualStyleBackColor = true;
            this.ProfileBtn.Click += new System.EventHandler(this.ProfileBtn_Click);
            // 
            // ShopBtn
            // 
            this.ShopBtn.BackgroundImage = global::LKSMart.Properties.Resources.shop;
            this.ShopBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.ShopBtn.Location = new System.Drawing.Point(302, 198);
            this.ShopBtn.Name = "ShopBtn";
            this.ShopBtn.Size = new System.Drawing.Size(147, 114);
            this.ShopBtn.TabIndex = 6;
            this.ShopBtn.UseVisualStyleBackColor = true;
            this.ShopBtn.Click += new System.EventHandler(this.ShopBtn_Click);
            // 
            // TransactionBtn
            // 
            this.TransactionBtn.BackgroundImage = global::LKSMart.Properties.Resources.transaction_history;
            this.TransactionBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.TransactionBtn.Location = new System.Drawing.Point(553, 198);
            this.TransactionBtn.Name = "TransactionBtn";
            this.TransactionBtn.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.TransactionBtn.Size = new System.Drawing.Size(147, 114);
            this.TransactionBtn.TabIndex = 7;
            this.TransactionBtn.UseVisualStyleBackColor = true;
            // 
            // PointBtn
            // 
            this.PointBtn.BackgroundImage = global::LKSMart.Properties.Resources.point_history;
            this.PointBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.PointBtn.Location = new System.Drawing.Point(787, 198);
            this.PointBtn.Name = "PointBtn";
            this.PointBtn.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.PointBtn.Size = new System.Drawing.Size(147, 114);
            this.PointBtn.TabIndex = 8;
            this.PointBtn.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(46, 175);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(68, 20);
            this.label1.TabIndex = 9;
            this.label1.Text = "PROFILE";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(298, 175);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(48, 20);
            this.label2.TabIndex = 10;
            this.label2.Text = "SHOP";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(536, 175);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(182, 20);
            this.label3.TabIndex = 11;
            this.label3.Text = "TRANSACTION HISTORY";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(783, 175);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(121, 20);
            this.label4.TabIndex = 12;
            this.label4.Text = "POINT HISTORY";
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1011, 401);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.PointBtn);
            this.Controls.Add(this.TransactionBtn);
            this.Controls.Add(this.ShopBtn);
            this.Controls.Add(this.ProfileBtn);
            this.Controls.Add(this.CartBtn);
            this.Controls.Add(this.LogoutBtn);
            this.Controls.Add(this.TimeLabel);
            this.Controls.Add(this.WelcomeLabel);
            this.Controls.Add(this.ProfilePb);
            this.Name = "MainForm";
            this.Text = "MainForm";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.MainForm_FormClosed);
            this.Load += new System.EventHandler(this.MainForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.ProfilePb)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox ProfilePb;
        private System.Windows.Forms.Label WelcomeLabel;
        private System.Windows.Forms.Label TimeLabel;
        private System.Windows.Forms.Button LogoutBtn;
        private System.Windows.Forms.Button CartBtn;
        private System.Windows.Forms.Button ProfileBtn;
        private System.Windows.Forms.Button ShopBtn;
        private System.Windows.Forms.Button TransactionBtn;
        private System.Windows.Forms.Button PointBtn;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
    }
}