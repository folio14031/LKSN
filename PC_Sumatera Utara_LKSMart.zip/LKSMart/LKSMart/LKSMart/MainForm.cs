﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace LKSMart {
    public partial class MainForm : Form {

        private static int id;

        public MainForm() {
            InitializeComponent();
        }

        private void MainForm_Load(object sender, EventArgs e) {
            if (Base.id == null) Close();
            else {
                id = (int) Base.id;
            }

            using (var dt = Db.queryDt($"SELECT * FROM [dbo].[customer] WHERE id = {id}")) {
                WelcomeLabel.Text = "Welcome, " + dt.Rows[0].ItemArray[1] + " !";
                TimeLabel.Text = DateTime.Now.ToString("dd MMMM yyyy, HH:mm:ss");

                var imageName = dt.Rows[0].ItemArray[9].ToString();

                if (!String.IsNullOrEmpty(imageName) || imageName != "") {
                    ProfilePb.BackgroundImage = Image.FromFile(Base.defaultProfilePath + imageName + ".png");
                } else {
                    ProfilePb.BackgroundImage = Image.FromFile(Base.defaultProfilePath + Base.defaultProfileName);
                }
            }
        }

        private void MainForm_FormClosed(object sender, FormClosedEventArgs e) {
            LoginForm.ActiveForm.Show();
        }

        private void ProfileBtn_Click(object sender, EventArgs e) {
            (new ProfileForm()).Show();
        }

        private void LogoutBtn_Click(object sender, EventArgs e) {
            Close();
        }

        private void ShopBtn_Click(object sender, EventArgs e) {
            (new ShopForm()).Show();
        }
    }
}
