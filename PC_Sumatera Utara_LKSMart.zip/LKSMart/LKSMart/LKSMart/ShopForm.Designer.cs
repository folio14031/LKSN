﻿
namespace LKSMart {
    partial class ShopForm {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.label1 = new System.Windows.Forms.Label();
            this.BackBtn = new System.Windows.Forms.Button();
            this.KeywordTb = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.price1Tb = new System.Windows.Forms.TextBox();
            this.price2Tb = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.ProductDgv = new System.Windows.Forms.DataGridView();
            this.prodPb = new System.Windows.Forms.PictureBox();
            this.NameLabel = new System.Windows.Forms.Label();
            this.PriceLabel = new System.Windows.Forms.Label();
            this.StockLabel = new System.Windows.Forms.Label();
            this.addToCartBtn = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.ProductDgv)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.prodPb)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(13, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(90, 37);
            this.label1.TabIndex = 0;
            this.label1.Text = "SHOP";
            // 
            // BackBtn
            // 
            this.BackBtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.BackBtn.Location = new System.Drawing.Point(910, 13);
            this.BackBtn.Name = "BackBtn";
            this.BackBtn.Size = new System.Drawing.Size(145, 51);
            this.BackBtn.TabIndex = 1;
            this.BackBtn.Text = "BACK";
            this.BackBtn.UseVisualStyleBackColor = true;
            this.BackBtn.Click += new System.EventHandler(this.BackBtn_Click);
            // 
            // KeywordTb
            // 
            this.KeywordTb.Location = new System.Drawing.Point(89, 108);
            this.KeywordTb.Name = "KeywordTb";
            this.KeywordTb.Size = new System.Drawing.Size(453, 20);
            this.KeywordTb.TabIndex = 2;
            this.KeywordTb.TextChanged += new System.EventHandler(this.KeywordTb_TextChanged_1);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(13, 111);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(57, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Keyword : ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(13, 147);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(70, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Price range : ";
            // 
            // price1Tb
            // 
            this.price1Tb.Location = new System.Drawing.Point(89, 144);
            this.price1Tb.MaxLength = 9;
            this.price1Tb.Name = "price1Tb";
            this.price1Tb.Size = new System.Drawing.Size(153, 20);
            this.price1Tb.TabIndex = 5;
            this.price1Tb.TextChanged += new System.EventHandler(this.price1Tb_TextChanged);
            // 
            // price2Tb
            // 
            this.price2Tb.Location = new System.Drawing.Point(283, 144);
            this.price2Tb.Name = "price2Tb";
            this.price2Tb.Size = new System.Drawing.Size(153, 20);
            this.price2Tb.TabIndex = 6;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(257, 147);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(10, 13);
            this.label4.TabIndex = 7;
            this.label4.Text = "-";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(467, 142);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 8;
            this.button2.Text = "Search";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // ProductDgv
            // 
            this.ProductDgv.AllowUserToAddRows = false;
            this.ProductDgv.AllowUserToDeleteRows = false;
            this.ProductDgv.AllowUserToOrderColumns = true;
            this.ProductDgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.ProductDgv.Location = new System.Drawing.Point(16, 193);
            this.ProductDgv.MultiSelect = false;
            this.ProductDgv.Name = "ProductDgv";
            this.ProductDgv.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.ProductDgv.Size = new System.Drawing.Size(526, 374);
            this.ProductDgv.TabIndex = 9;
            this.ProductDgv.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.ProductDgv_CellClick);
            this.ProductDgv.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.ProductDgv_CellContentClick);
            // 
            // prodPb
            // 
            this.prodPb.Location = new System.Drawing.Point(563, 193);
            this.prodPb.Name = "prodPb";
            this.prodPb.Size = new System.Drawing.Size(136, 122);
            this.prodPb.TabIndex = 10;
            this.prodPb.TabStop = false;
            // 
            // NameLabel
            // 
            this.NameLabel.AutoSize = true;
            this.NameLabel.Location = new System.Drawing.Point(714, 193);
            this.NameLabel.Name = "NameLabel";
            this.NameLabel.Size = new System.Drawing.Size(41, 13);
            this.NameLabel.TabIndex = 11;
            this.NameLabel.Text = "Name :";
            // 
            // PriceLabel
            // 
            this.PriceLabel.AutoSize = true;
            this.PriceLabel.Location = new System.Drawing.Point(718, 222);
            this.PriceLabel.Name = "PriceLabel";
            this.PriceLabel.Size = new System.Drawing.Size(37, 13);
            this.PriceLabel.TabIndex = 12;
            this.PriceLabel.Text = "Price :";
            // 
            // StockLabel
            // 
            this.StockLabel.AutoSize = true;
            this.StockLabel.Location = new System.Drawing.Point(714, 252);
            this.StockLabel.Name = "StockLabel";
            this.StockLabel.Size = new System.Drawing.Size(41, 13);
            this.StockLabel.TabIndex = 13;
            this.StockLabel.Text = "Stock :";
            // 
            // addToCartBtn
            // 
            this.addToCartBtn.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.addToCartBtn.Location = new System.Drawing.Point(563, 487);
            this.addToCartBtn.Name = "addToCartBtn";
            this.addToCartBtn.Size = new System.Drawing.Size(492, 78);
            this.addToCartBtn.TabIndex = 14;
            this.addToCartBtn.Text = "Add To Cart";
            this.addToCartBtn.UseVisualStyleBackColor = true;
            // 
            // ShopForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1067, 578);
            this.Controls.Add(this.addToCartBtn);
            this.Controls.Add(this.StockLabel);
            this.Controls.Add(this.PriceLabel);
            this.Controls.Add(this.NameLabel);
            this.Controls.Add(this.prodPb);
            this.Controls.Add(this.ProductDgv);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.price2Tb);
            this.Controls.Add(this.price1Tb);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.KeywordTb);
            this.Controls.Add(this.BackBtn);
            this.Controls.Add(this.label1);
            this.Name = "ShopForm";
            this.Text = "ShopFOrm";
            this.Load += new System.EventHandler(this.ShopForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.ProductDgv)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.prodPb)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button BackBtn;
        private System.Windows.Forms.TextBox KeywordTb;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox price1Tb;
        private System.Windows.Forms.TextBox price2Tb;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.DataGridView ProductDgv;
        private System.Windows.Forms.PictureBox prodPb;
        private System.Windows.Forms.Label PriceLabel;
        private System.Windows.Forms.Label StockLabel;
        private System.Windows.Forms.Button addToCartBtn;
        private System.Windows.Forms.Label NameLabel;
    }
}